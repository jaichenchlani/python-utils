"""
Jai's Personal Python Utilities

A collection of reusable modules for various projects.
"""

__version__ = "1.0.0"
__author__ = "Jai"